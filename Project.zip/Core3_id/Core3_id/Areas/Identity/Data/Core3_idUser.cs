﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core3_id.Data;
using Microsoft.AspNetCore.Identity;

namespace Core3_id.Areas.Identity.Data
{
    // Add profile data for application users by adding properties to the Core3_idUser class
    public class Core3_idUser : IdentityUser
    {
        public virtual ICollection<ApplicationUserClaim> Claims { get; set; }
        public virtual ICollection<ApplicationUserLogin> Logins { get; set; }
        public virtual ICollection<ApplicationUserToken> Tokens { get; set; }
        public virtual ICollection<ApplicationUserRole> UserRoles { get; set; }


        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public string Country { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Postalcode { get; set; }

    }
}
