﻿using System;
using Core3_id.Areas.Identity.Data;
using Core3_id.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: HostingStartup(typeof(Core3_id.Areas.Identity.IdentityHostingStartup))]
namespace Core3_id.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {

            builder.ConfigureServices((context, services) => {
                services.AddDbContext<ApplicationDbContext>(options =>
                    options.UseMySql(
                        context.Configuration.GetConnectionString("Core3_idContextConnection")));

                //services.AddDefaultIdentity<Core3_idUser>(options => options.SignIn.RequireConfirmedAccount = true).AddEntityFrameworkStores<Core3_idContext>();
            });
        }
    }
}