﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core3_id.Services;
using Microsoft.AspNetCore.Mvc;

namespace Core3_id.Controllers
{
    public class AccountController : Controller
    {
        private readonly IEmailSender _emailService;
        public AccountController(IEmailSender emailService)
        {
            _emailService = emailService;
        }

        [HttpPost]
        [Route("account/send-email")]
        public async Task<IActionResult> SendEmailAsync(/*[FromUri]*/string email, string subject, string message)
        {
            await _emailService.SendEmail(email, subject, message);
            return Ok();
        }
    }
}