﻿using Core3_id.Areas.Identity.Data;
using Core3_id.Data;
using Core3_id.Models;
using Core3_id.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Controllers
{
    public class AdministrationController : Controller
    {
        private readonly RoleManager<ApplicationRole> roleManager;
        private readonly UserManager<Core3_idUser> UserManager;
        public readonly ApplicationDbContext _db;

        public AdministrationController(RoleManager<ApplicationRole> roleManager,
                                        UserManager<Core3_idUser> userManager,
                                        ApplicationDbContext db)
        {
            this.roleManager = roleManager;
            this.UserManager = userManager;
            this._db = db;
        }

        [HttpGet]
        public IActionResult CreateRole()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateRole(RoleViewModel rvm)
        {
            if (ModelState.IsValid)
            {
                ApplicationRole irole = new ApplicationRole
                {
                    Name = rvm.roleName
                };

                IdentityResult result = await roleManager.CreateAsync(irole);

                if (result.Succeeded)
                {
                    return RedirectToAction("ListRoles", "Administration");
                }
            }
            return View(rvm);
        }


        public async Task<IActionResult> DeleteRole(string Id)
        {
            var role = await roleManager.FindByIdAsync(Id);

            if (role == null)
            {
                ViewBag.ErrorMessage = "Nope";
            }
            else
            {
                var result = await roleManager.DeleteAsync(role);

                if (result.Succeeded)
                {
                    return RedirectToAction("ListRoles");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            return View("ListRoles");
        }

        [HttpGet]
        public IActionResult ListRoles()
        {
            var roles = roleManager.Roles;
            return View(roles);
        }

        [HttpGet]
        public async Task<IActionResult> EditRole(string id)
        {
            var role = await roleManager.FindByIdAsync(id);

            if (role == null)
            {
                ViewBag.ErrorMessage = $"Role with Id = {id} cannot be found";
                return View("Error");
            }

            var model = new EditRole
            {
                Id = role.Id,
                RoleName = role.Name
            };

            foreach (var user in await UserManager.GetUsersInRoleAsync(role.Name))
            {
                model.Users.Add(user.UserName);
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> EditRole(EditRole model)
        {
            var role = await roleManager.FindByIdAsync(model.Id);

            if (role == null)
            {
                ViewBag.ErrorMessage = $"Role with Id = {model.Id} cannot be found";
                return View("Error");
            }
            else
            {
                role.Name = model.RoleName;
                var result = await roleManager.UpdateAsync(role);

                if (result.Succeeded)
                {
                    return RedirectToAction("ListRoles");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }

                return View(model);
            }
        }

        [HttpGet]
        public async Task<IActionResult> EditUsersInRole(string roleId)
        {
            ViewBag.roleId = roleId;

            var role = await roleManager.FindByIdAsync(roleId);

            if (role == null)
            {
                ViewBag.ErrorMessage = "Nope";
            }

            var model = new List<UserRoleViewModel>();
            var users = new List<Core3_idUser>();

            foreach (var user in UserManager.Users)
            {
                users.Add(user);
            }

            for (var i = 0; i < users.Count; i++)
            {
                var UserRole = new UserRoleViewModel
                {
                    UserId = users[i].Id,
                    UserName = users[i].UserName
                };

                if (await UserManager.IsInRoleAsync(users[i], role.Name))
                {
                    UserRole.IsSelected = true;
                }
                else
                {
                    UserRole.IsSelected = false;
                }

                model.Add(UserRole);
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> EditUsersInRole(List<UserRoleViewModel> model, string roleId)
        {
            var role = await roleManager.FindByIdAsync(roleId);

            if (role == null)
            {
                ViewBag.ErrorMessage = $"Role with Id = {roleId} cannot be found";
                return View("NotFound");
            }

            for (int i = 0; i < model.Count; i++)
            {
                var user = await UserManager.FindByIdAsync(model[i].UserId);

                IdentityResult result = null;

                if (model[i].IsSelected && !(await UserManager.IsInRoleAsync(user, role.Name)))
                {
                    result = await UserManager.AddToRoleAsync(user, role.Name);
                    switch (role.Name)
                    {
                        case "Shipper":
                            var shipper = new Shipper
                            {
                                Id = user.Id,
                                Name = user.Name,
                                PhoneNumber = user.PhoneNumber
                            };
                            _db.Add(shipper);
                            await _db.SaveChangesAsync();
                            break;
                        case "Storekeeper":
                            var sk = new Storekeeper
                            {
                                Id = user.Id,
                                Name = user.Name,
                            };
                            _db.Add(sk);
                            await _db.SaveChangesAsync();
                            break;
                    }
                }
                else if (!model[i].IsSelected && await UserManager.IsInRoleAsync(user, role.Name))
                {
                    result = await UserManager.RemoveFromRoleAsync(user, role.Name);
                    switch (role.Name)
                    {
                        case "Shipper":
                            var shipper = new Shipper
                            {
                                Id = user.Id,//"S" + (_db.Shippers.Count()+1).ToString(), 
                                Name = user.Name,
                                PhoneNumber = user.PhoneNumber
                            };
                            _db.Remove(shipper);
                            await _db.SaveChangesAsync();
                            break;
                        case "Storekeeper":
                            var sk = new Storekeeper
                            {
                                Name = user.Name,
                            };
                            _db.Remove(sk);
                            await _db.SaveChangesAsync();
                            break;
                    }
                }
                else
                {
                    continue;
                }

                if (result.Succeeded)
                {
                    if (i < (model.Count - 1))
                        continue;
                    else
                        return RedirectToAction("EditRole", new { Id = roleId });
                }
            }

            return RedirectToAction("EditRole", new { Id = roleId });
        }

        public IActionResult ListUsers()
        {
            return View(_db.Core3_IdUsers.ToList());
        }

        [HttpGet]
        public async Task<IActionResult> EditUser(string id)
        {
            var user = await UserManager.FindByIdAsync(id);

            ViewBag.Name = user.Name;

            var model = new EditUserModel
            {
                Id = user.Id,
                Name = user.Name,
                DOB = user.DOB,
                Address = user.Address,
                City = user.City,
                PhoneNumber = user.PhoneNumber,
                Postalcode = user.Postalcode
            };

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> EditUser(EditUserModel model)
        {
            var user = await UserManager.FindByIdAsync(model.Id);

            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{UserManager.GetUserId(User)}'.");
            }

            var phoneNumber = await UserManager.GetPhoneNumberAsync(user);
            if (model.PhoneNumber != phoneNumber)
            {
                var setPhoneResult = await UserManager.SetPhoneNumberAsync(user, model.PhoneNumber);
                if (!setPhoneResult.Succeeded)
                {
                    var userId = await UserManager.GetUserIdAsync(user);
                    throw new InvalidOperationException($"Unexpected error occurred setting phone number for user with ID '{userId}'.");
                }
            }

            if (model.Name != null && model.Name != user.Name)
            {
                user.Name = model.Name;
            }

            if (model.Name != null && model.DOB != user.DOB)
            {
                user.DOB = model.DOB;
            }

            if (model.Name != null && model.Address != user.Address)
            {
                user.Address = model.Address;
            }

            if (model.Name != null && model.City != user.City)
            {
                user.City = model.City;
            }

            if (model.Name != null && model.Postalcode != user.Postalcode)
            {
                user.Postalcode = model.Postalcode;
            }

            if (model.Name != null && model.PhoneNumber != user.PhoneNumber)
            {
                user.PhoneNumber = model.PhoneNumber;
            }

            await UserManager.UpdateAsync(user);

            var shipper = _db.Shippers.FirstOrDefault(s => s.Id == model.Id);
            if (shipper != null && shipper.PhoneNumber != model.PhoneNumber)
            {
                shipper.PhoneNumber = model.PhoneNumber;
                _db.Shippers.Update(shipper);
                await _db.SaveChangesAsync();
            }

            return RedirectToAction("ListUsers");
        }

        public async Task<IActionResult> DeleteUser(string Id)
        {
            var user = await UserManager.FindByIdAsync(Id);

            if (user == null)
            {
                ViewBag.ErrorMessage = "Nope";
            }
            else
            {
                var result = await UserManager.DeleteAsync(user);

                if (result.Succeeded)
                {
                    return RedirectToAction("ListUsers");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            return View("ListUsers");
        }


        [HttpGet]
        public IActionResult CreateTerritory()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateTerritory(Territories terr)
        {
            if (ModelState.IsValid)
            {
                Territories t = new Territories
                {
                    Id = terr.Name,
                    Name = terr.Name,
                    Central = terr.Central
                };

                _db.Add(t);

                var result = await _db.SaveChangesAsync();

                if (result != 0)
                {
                    return RedirectToAction("ListTerritory", "Managment");
                }
            }
            return View(terr);
        }


    }
}
