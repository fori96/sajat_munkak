﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Core3_id.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Core3_id.Areas.Identity.Data;

namespace Core3_id.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public readonly ApplicationDbContext _db;
        public readonly UserManager<Core3_idUser> userManager;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext db, UserManager<Core3_idUser> userManager)
        {
            _logger = logger;
            _db = db;
            this.userManager = userManager;
        }

        [AllowAnonymous]
        public IActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult FeedbackGiving()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> FeedbackGiving(Feedbacks model)
        {
            if (model == null)
            {
                return View("Error");
            }

            var user = await userManager.FindByNameAsync(model.User);
            var id = DateTime.Now + model.User;

            Feedbacks fb = new Feedbacks()
            {
                Id = id,
                User = user.Id,
                Subject = model.Subject,
                Description = model.Description
            };

            _db.Feedbacks.Add(fb);
            await _db.SaveChangesAsync();

            return View("Index");
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
