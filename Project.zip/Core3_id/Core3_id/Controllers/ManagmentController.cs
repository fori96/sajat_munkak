﻿using Core3_id.Areas.Identity.Data;
using Core3_id.Data;
using Core3_id.Models;
using Core3_id.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Controllers
{
    [Authorize(Policy = "Managment")]
    public class ManagmentController : Controller
    {
        public readonly ApplicationDbContext _db;
        public readonly UserManager<Core3_idUser> UserManager;
        private readonly RoleManager<ApplicationRole> roleManager;

        public ManagmentController(ApplicationDbContext db, RoleManager<ApplicationRole> roleManager, UserManager<Core3_idUser> userManager)
        {
            this.roleManager = roleManager;
            _db = db;
            this.UserManager = userManager;
        }

        [HttpGet]
        public IActionResult ListPackages()
        {

            return View(_db.Package.ToList());
        }

        public IActionResult ListTerritory()
        {
            return View(_db.Territories.ToList());
        }

        public async Task<IActionResult> ListWorkers()
        {
            var users = _db.Core3_IdUsers.ToList();

            var list = new List<Core3_idUser>();

            foreach (var user in users)
            {
                if (await UserManager.IsInRoleAsync(user,"Shipper") || await UserManager.IsInRoleAsync(user, "Storekeeper"))
                    list.Add(user);
            }

            ViewBag.Shippers = _db.Shippers.ToList();

            return View(list);
        }

        [HttpGet]
        public async Task<IActionResult> EditTerritory(string id)
        {
            var terr = await _db.Territories.FindAsync(id);

            if (terr == null)
            {
                ViewBag.ErrorMessage = $"Role with Id = {id} cannot be found";
                return View("Error");
            }

            var model = new EditTerritoryViewModel
            {
                Id = terr.Id,
                Name = terr.Name,
                Central = terr.Central
            };

            var sList = _db.Shippers.ToList();

            for (int i = 0; i < sList.Count(); i++)
            {
                if (sList[i].Territory == model.Id)
                {
                    model.Shippers.Add(sList[i].Id);
                }
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> EditTerritory(Territories model)
        {
            var terr = await _db.Territories.FindAsync(model.Id);

            if (terr == null)
            {
                ViewBag.ErrorMessage = $"Role with Id = {model.Id} cannot be found";
                return View("Error");
            }
            else
            {
                terr.Name = model.Name;
                _db.Update(terr);
                var result = await _db.SaveChangesAsync();

                if (result == 0)
                {
                    return View(model);
                }

                return RedirectToAction("ListTerritory");
            }
        }

        [HttpGet]
        public async Task<IActionResult> AddToTerritory(string Id)
        {
            ViewBag.tId = Id;

            var terr = await _db.Territories.FindAsync(Id);

            if (terr == null)
            {
                ViewBag.ErrorMessage = "Nope";
            }

            var model = new List<ShipperInTerritory>();
            var shippers = new List<Shipper>();

            foreach (var user in _db.Shippers.ToList())
            {
                shippers.Add(user);
            }

            for (var i = 0; i < shippers.Count; i++)
            {
                var STerritory = new ShipperInTerritory
                {
                    SId = shippers[i].Id,
                    Name = shippers[i].Name
                };

                if (shippers[i].Territory == terr.Id)
                {
                    STerritory.IsSelected = true;
                }
                else
                {
                    STerritory.IsSelected = false;
                }

                model.Add(STerritory);
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> AddToTerritory(List<ShipperInTerritory> model, string Id)
        {
            var terr = await _db.Territories.FindAsync(Id);

            if (terr == null)
            {
                ViewBag.ErrorMessage = $"Role with Id = {Id} cannot be found";
                return View("Error");
            }

            for (int i = 0; i < model.Count; i++)
            {
                var ship = await _db.Shippers.FindAsync(model[i].SId);

                Shipper shipper = new Shipper();

                if (model[i].IsSelected && ship.Territory != terr.Id)
                {
                    shipper = _db.Shippers.SingleOrDefault(s => s.Id == model[i].SId);
                    shipper.Territory = terr.Id;
                    _db.Update(shipper);
                    await _db.SaveChangesAsync();
                }
                else if (!model[i].IsSelected && ship.Territory == terr.Id)
                {
                    //shipper = _db.Shippers.SingleOrDefault(s => s.Territory == terr.Id);
                    shipper = _db.Shippers.SingleOrDefault(s => s.Id == model[i].SId);
                    shipper.Territory = "";
                    _db.Update(shipper);
                    await _db.SaveChangesAsync();
                }
                else
                {
                    continue;
                }

                if (shipper != null)
                {
                    if (i < (model.Count - 1))
                        continue;
                    else
                        return RedirectToAction("EditTerritory", new { Id = Id });
                }
            }

            return RedirectToAction("EditTerritory", new { Id = Id });
        }

        [HttpGet]
        public async Task<IActionResult> AddToStore(string Id)
        {
            var sk = await _db.Storekeepers.FindAsync(Id);

            if (sk == null)
            {
                ViewBag.ErrorMessage = "Nope";
            }

            var model = new List<AddToStoreVM>();
            var whs = new List<Warehouse>();

            foreach (var w in _db.Warehouses.ToList())
            {
                whs.Add(w);
            }

            for (var i = 0; i < whs.Count; i++)
            {
                var adds = new AddToStoreVM
                {
                    Name = whs[i].Name,
                    WhId = whs[i].WhId,
                };

                if (whs[i].WhId == sk.WhId)
                {
                    adds.IsSelected = true;
                }
                else
                {
                    adds.IsSelected = false;
                }

                model.Add(adds);
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> AddToStore(List<AddToStoreVM> model, string Id)
        {
            var sk = await _db.Storekeepers.FindAsync(Id);

            if (sk == null)
            {
                ViewBag.ErrorMessage = "Nope";
            }

            for (int i = 0; i < model.Count; i++)
            {
                var w = await _db.Warehouses.FindAsync(model[i].WhId);

                if (model[i].IsSelected && w.WhId != sk.WhId)
                {
                    sk.WhId = model[i].WhId;
                    _db.Storekeepers.Update(sk);
                    await _db.SaveChangesAsync();
                }
                else if (!model[i].IsSelected && w.WhId == sk.WhId)
                {
                    sk.WhId = "";
                    _db.Storekeepers.Update(sk);
                    await _db.SaveChangesAsync();
                }
            }
            return RedirectToAction("ListWorkers");
        }

        [HttpGet]
        public IActionResult AddToShipper(string Id)
        {
            var model = new List<AddShipperToPackageVM>();
            var shippers = new List<Shipper>();

            foreach (var s in _db.Shippers.ToList())
            {
                shippers.Add(s);
            }
            for (var i = 0; i < shippers.Count; i++)
            {
                var asd = new AddShipperToPackageVM
                {
                    SId = shippers[i].Id,
                    Name = shippers[i].Name,
                    PId = Id
                };

                var shipping = _db.Shippings.Where(s => s.ShipperId == shippers[i].Id && s.PackageId == Id);

                if (shipping != null)
                {
                    asd.IsSelected = true;
                }

                model.Add(asd);
            }

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> AddToShipper(List<AddShipperToPackageVM> model, string Id)
        {
            var package = await _db.Package.FindAsync(Id);

            if (package == null)
            {
                ViewBag.ErrorMessage = $"Role with Id = {Id} cannot be found";
                return View("Error");
            }

            var shipping = new Shipping
            {
                PackageId = package.PackageID
            };

            for (int i = 0; i < model.Count(); i++)
            {
                var s = _db.Shippings.SingleOrDefault(s => s.ShipperId == model[i].SId && s.PackageId == model[i].PId);
                if (model[i].IsSelected && (s == null))
                {
                    if (package.Status == "feladva")
                    {
                        var user = await UserManager.FindByIdAsync(package.Sender);
                        package.Status = "felvétel alatt";
                        shipping.WhereFrom = user.Postalcode + ", " + user.City + " " + user.Address;
                        shipping.WhereTo = _db.Warehouses.SingleOrDefault(
                            w => w.Territory == (_db.Shippers.SingleOrDefault(s => s.Id == model[i].SId)).Territory).Name;
                    }
                    if (package.Status == "raktárban ellenőrizve")
                    {
                        var storings = _db.Storings.SingleOrDefault(s => s.PackageId == package.PackageID);
                        package.Status = "átszállítás alatt";
                        var store = await _db.Warehouses.FindAsync(storings.WhId);
                        shipping.WhereFrom = store.Postalcode + ", " + store.City + " " + store.Address;
                        shipping.WhereTo = _db.Warehouses.SingleOrDefault(
                            w => w.Territory == (_db.Shippers.SingleOrDefault(s => s.Id == model[i].SId)).Territory).Name;
                    }
                    if (package.Status == "raktárban ellenőrizve(2)")
                    {
                        shipping.WhereFrom = _db.Warehouses.SingleOrDefault(
                            w => w.Territory == (_db.Shippers.SingleOrDefault(s => s.Id == model[i].SId)).Territory).Name;
                        package.Status = "kiszállítás alatt";
                        var user = await UserManager.FindByIdAsync(package.Recipient);
                        shipping.WhereTo = user.Postalcode + ", " + user.City + " " + user.Address;
                    }
                    if (package.Status == "raktárba ellenőrizve (vissza)")
                    {
                        var storings = _db.Storings.SingleOrDefault(s => s.PackageId == package.PackageID);
                        package.Status = "átszállítás alatt (vissza)";
                        var store = await _db.Warehouses.FindAsync(storings.WhId);
                        shipping.WhereFrom = store.Postalcode + ", " + store.City + " " + store.Address;
                        shipping.WhereTo = _db.Warehouses.SingleOrDefault(
                            w => w.Territory == (_db.Shippers.SingleOrDefault(s => s.Id == model[i].SId)).Territory).Name;
                    }
                    if (package.Status == "raktárba ellenőrizve (vissza,2)")
                    {
                        shipping.WhereFrom = _db.Warehouses.SingleOrDefault(
                            w => w.Territory == (_db.Shippers.SingleOrDefault(s => s.Id == model[i].SId)).Territory).Name;
                        package.Status = "kiszállítás alatt (vissza)";
                        var user = await UserManager.FindByIdAsync(package.Sender);
                        shipping.WhereTo = user.Postalcode + ", " + user.City + " " + user.Address;
                    }

                    _db.Update(package);
                    await _db.SaveChangesAsync();

                    shipping.ShipperId = model[i].SId;
                    shipping.Done = false;

                    _db.Add(shipping);
                    await _db.SaveChangesAsync();
                }
            }

            return RedirectToAction("ListPackages");
        }

        public IActionResult ListFeednacks()
        {
            return View(_db.Territories.ToList());
        }
    }
}
