﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Core3_id.Models;
using Core3_id.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Core3_id.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity.UI.Services;
using IEmailSender = Core3_id.Services.IEmailSender;

namespace Core3_id.Controllers
{
    [Authorize]
    public class PackagesController : Controller
    {
        //private readonly RoleManager<ApplicationRole> roleManager;
        public readonly ApplicationDbContext _db;
        public readonly UserManager<Core3_idUser> userManager;
        private readonly IEmailSender _emailSender;

        public PackagesController(ApplicationDbContext db, UserManager<Core3_idUser> userManager, 
            IEmailSender emailSender/*, RoleManager<ApplicationRole> roleManager*/)
        {
            _db = db;
            this.userManager = userManager;
            package = new Package();
            _emailSender = emailSender;
            //this.roleManager = roleManager;
        }

        public Package package;

        [AllowAnonymous]
        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Policy = "Insiders")]
        public async Task<IActionResult> List(int num = 0)
        {
            var user = await userManager.GetUserAsync(User);
            var list = _db.Package.ToList();
            List<Package> plist = new List<Package>();

            //if (await userManager.IsInRoleAsync(user, "User") && num == 1)
            //{
            //    foreach (var p in list)
            //    {
            //        if (p.Sender == user.Id)
            //            plist.Add(p);
            //    }

            //    return View(plist.OrderBy(d => d.ShipDate).ToList());
            //}else 
            if (await userManager.IsInRoleAsync(user, "User") && num == 2)
            {
                foreach (var p in list)
                {
                    if (p.Recipient == user.Id)
                        plist.Add(p);
                }

                return View(plist.OrderBy(d => d.ShipDate).ToList());
            }

            return View(list.OrderBy(d => d.ShipDate).ToList());

        }

        [Authorize(Policy = "User")]
        public async Task<IActionResult> OwnPackages()
        {
            var user = await userManager.GetUserAsync(User);
            var list = _db.Package.ToList();
            List<Package> plist = new List<Package>();

            if (await userManager.IsInRoleAsync(user, "User"))
            {
                foreach (var p in list)
                {
                    if (p.Sender == user.Id)
                        plist.Add(p);
                }

                return View(plist.OrderBy(d => d.ShipDate).ToList());
            }

            return View(list.OrderBy(d => d.ShipDate).ToList());
        }

        [HttpGet]
        public async Task<IActionResult> Create(int num = 1)
        {
            if (num == 1)
            {
                var user = await userManager.GetUserAsync(User);
                if (user == null)
                {
                    return NotFound($"Unable to load user with ID '{userManager.GetUserId(User)}'.");
                }


                return View();

            }
            return View();

        }

        [AllowAnonymous]
        public async Task<IActionResult> Details(string PackageID)
        {
            if (PackageID == null)
            {
                return View("Error");
            }

            var package = await _db.Package.SingleOrDefaultAsync(m => m.PackageID == PackageID);

            if (package == null)
            {
                return NotFound();
            }

            return View(package);
        }

        public async Task<IActionResult> DeletePackage(string Id)
        {
            if (ModelState.IsValid)
            {
                if (Id == null)
                {
                    return View("Error");
                }

                var package = await _db.Package.SingleOrDefaultAsync(p => p.PackageID == Id);

                if (package == null)
                {
                    ViewBag.ErrorMessage = "Nope";
                }
                else
                {
                    string message = $"A {package.PackageID} azonosítójú csomag törlésre került." +
                                $"A törlés oka lehetett: - 3. sikertelen csomag felvétel próbálkozás" +
                                $" - sikertelen kiszállítás kisérlet mindkét félnek (sikertelen kézbesítés után a feladó se vedte  vissza)." +
                                $"" +
                                $"Sajnáljuk a történteket" +
                                $"" +
                                $"Üdvözlettel a Sahara Caravan csapata";
                    var sender = await userManager.FindByIdAsync(package.Sender);
                    await _emailSender.SendEmail(sender.Email, "Törölt csomag",message);
                    var rec = await userManager.FindByIdAsync(package.Recipient);
                    await _emailSender.SendEmail(rec.Email, "Törölt csomag",message);

                    _db.Remove(package);
                    await _db.SaveChangesAsync();
                    return RedirectToAction("List");
                }
            }
            
            return View("List");
        }

        [HttpPost]
        public async Task<IActionResult> CreateFull(PackageDataModel model)
        {
            var sen = await userManager.GetUserAsync(User);
            if (sen == null)
            {
                return NotFound($"Unable to load user to sender with ID '{userManager.GetUserId(User)}'.");
            }

            string destination = null;
            if(model.Recipient != null)
            {
                var rec = await userManager.FindByNameAsync(model.Recipient);
                if (rec == null)
                {
                    return NotFound($"Unable to load user to recipient with ID '{userManager.FindByNameAsync(model.Recipient)}'.");
                }
                destination = rec.Id;
            }
            else if(model.PickupPoint != null)
            {
                destination = model.PickupPoint;
            }
            else if (model.PickupPoint != null)
            {
                destination = model.OuterAddresses.Id;
            }

            package = new Package
            {
                PackageID = DateTime.Today.Month.ToString() + DateTime.Today.Day + DateTime.Now.Hour + DateTime.Now.Minute,
                Sender = sen.Id,
                Recipient = destination,
                Status = "feladva",
                Type = model.Type,
                Size = (model.Type == "levél" ? 0 : model.Size),
                Prize = (model.Type == "levél" ? 990 : (990 + model.Size * 200)),
                ShipDate = DateTime.Today.AddDays(2),
                DeliveryDate = DateTime.Today.AddDays(5)
            };

            _db.Add(package);

             var result = await _db.SaveChangesAsync();
            
            if (result == 1)
                return RedirectToAction("Success",package);

            return View("Create");
        }

        public async Task<IActionResult> Success(Package model)
        {
            var package = await _db.Package.SingleOrDefaultAsync(p => p.PackageID == model.PackageID);

            var sender = await userManager.FindByIdAsync(package.Sender);
            await _emailSender.SendEmail(sender.Email, "Csomagot adott fel",
                        $"A csomagot adott fel a Sahara Caravan szolgáltatáson keresztül. \t" +
                        $"Kérjük látogassa meg oldalunk a csomag követéséhez." +
                        $"Csomag azonósítója: {package.PackageID}" +
                        $"" +
                        $"Köszönjük, hogy minket választott." +
                        $"" +
                        $"Üdvözlettel a Sahara Caravan csapata");
            var rec = await userManager.FindByIdAsync(package.Recipient);
            await _emailSender.SendEmail(rec.Email, "Csomagot adtak fel önnek",
                        $"Csomagot adtak fel az ön számára. \t" +
                        $"Kérjük látogassa meg oldalunk a csomag követéséhez." +
                        $"Csomag azonósítója: {package.PackageID}" +
                        $"" +
                        $"Kiszállítás előtt, iletve probléma esetén értesítjük önt." +
                        $"" +
                        $"Üdvözlettel a Sahara Caravan csapata");

            return View(package);
        }
    }
}