﻿using Core3_id.Areas.Identity.Data;
using Core3_id.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Controllers
{
    [Authorize(Policy = "Shippers")]
    public class ShipperController : Controller
    {
        public readonly ApplicationDbContext _db;
        public readonly UserManager<Core3_idUser> userManager;
        public readonly PackagesController pc;

        public ShipperController(ApplicationDbContext db, UserManager<Core3_idUser> userManager)
        {
            _db = db;
            this.userManager = userManager;
            package = new Package();
        }

        public Package package;


        public async Task<IActionResult> GotShippings()
        {
            var shipper = await userManager.FindByNameAsync(User.Identity.Name);
            var shippings = _db.Shippings.ToList();
            var model = new List<Shipping>();

            for (int i = 0; i < shippings.Count(); i++)
            {
                if (shippings[i].ShipperId == shipper.Id && !shippings[i].Accepted) 
                {
                    model.Add(shippings[i]);
                }
            }

            return View(model);
        }

        public async Task<IActionResult> AcceptShipping(int id)
        {
            var shipping = _db.Shippings.SingleOrDefault(s => s.Id == id);

            shipping.Accepted = true;

            _db.Update(shipping);
            await _db.SaveChangesAsync();

            return View("GotShippings");
        }

        public async Task<IActionResult> RefuseShipping(int id)
        {
            var shipping = _db.Shippings.SingleOrDefault(s => s.Id == id);

            shipping.Accepted = false;

            _db.Update(shipping);
            await _db.SaveChangesAsync();

            return View("GotShippings");
        }

        public async Task<IActionResult> UpdateStatus(int Id)
        {
            //var shipping = _db.Shippings.FirstOrDefault(s => s.Id == Id);
            var shipping = await _db.Shippings.FindAsync(Id);
            //var package = _db.Package.FirstOrDefault(p => p.PackageID == shipping.PackageId);
            var package = await _db.Package.FindAsync(shipping.PackageId);

            switch (package.Status)
            {
                case "felvétel alatt":
                    {
                        package.Status = "raktárba szállítva";
                        var storing = new Storing
                        {
                            PackageId = package.PackageID,
                            WhId = shipping.WhereTo,
                            RecieveDate = DateTime.Today,
                        };
                        _db.Add(storing);
                        await _db.SaveChangesAsync();
                    }
                    break;
                case "felvétel alatt(1)":
                    {
                        package.Status = "raktárba szállítva";
                        var storing = new Storing
                        {
                            PackageId = package.PackageID,
                            WhId = shipping.WhereTo,
                            RecieveDate = DateTime.Today,
                        };
                        _db.Add(storing);
                        await _db.SaveChangesAsync();
                    }
                    break;
                case "felvétel alatt(2)":
                    {
                        package.Status = "raktárba szállítva";
                        var storing = new Storing
                        {
                            PackageId = package.PackageID,
                            WhId = shipping.WhereTo,
                            RecieveDate = DateTime.Today,
                        };
                        _db.Add(storing);
                        await _db.SaveChangesAsync();
                    }
                    break;
                case "átszállítás alatt":
                    {
                        package.Status = "raktárba szállítva(2)";
                        var storing = new Storing
                        {
                            PackageId = package.PackageID,
                            WhId = shipping.WhereTo,
                            RecieveDate = DateTime.Today,
                        };
                        _db.Add(storing);
                        await _db.SaveChangesAsync();
                    }
                    break;
                case "kiszállítás alatt":
                    package.Status = "kész";
                    break;
                case "kiszállítás alatt(1)":
                    package.Status = "kész";
                    break;
                case "kiszállítás alatt(2)":
                    package.Status = "kész";
                    break;
                case "vissza a feladónak":
                    package.Status = "raktárba szállítva (vissza)";
                    break;
                default:
                    break;
            }

            shipping.Done = true;

            _db.Update(package);
            await _db.SaveChangesAsync();

            _db.Update(shipping);
            await _db.SaveChangesAsync();

            return RedirectToAction("GottShippings");
        }

        public async Task<IActionResult> Failed(int Id)
        {
            var shipping = _db.Shippings.FirstOrDefault(s => s.Id == Id);
            var package = _db.Package.FirstOrDefault(p => p.PackageID == shipping.PackageId);

            if (package.Status == "felvétel alatt")
            {
                package.Status = "sikertelen felvétel(1)";

                shipping.Done = true;

                _db.Update(package);
                await _db.SaveChangesAsync();

                _db.Update(shipping);
                await _db.SaveChangesAsync();
            }

            if (package.Status == "sikertelen felvétel(1)")
            {
                package.Status = "sikertelen felvétel(2)";

                shipping.Done = true;

                _db.Update(package);
                await _db.SaveChangesAsync();

                _db.Update(shipping);
                await _db.SaveChangesAsync();
            }

            if (package.Status == "sikertelen felvétel(2)")
            {
                await pc.DeletePackage(package.PackageID);
            }

            if (package.Status == "kiszállítás alatt")
            {
                package.Status = "sikertelen kiszállítás(1)";

                shipping.Done = true;

                _db.Update(package);
                await _db.SaveChangesAsync();

                _db.Update(shipping);
                await _db.SaveChangesAsync();
            }

            if (package.Status == "kiszállítás alatt(1)")
            {
                package.Status = "sikertelen kiszállítás(2)";

                shipping.Done = true;

                _db.Update(package);
                await _db.SaveChangesAsync();

                _db.Update(shipping);
                await _db.SaveChangesAsync();
            }

            if (package.Status == "kiszállítás alatt(2)")
            {
                package.Status = "vissza a feladónak";

                package.Recipient = package.Sender;

                _db.Update(package);
                await _db.SaveChangesAsync();

                _db.Remove(shipping);
                await _db.SaveChangesAsync();
            }

            return RedirectToAction("MyShippings");
        }

        [HttpGet]
        public async Task<IActionResult> MyShippings()
        {
            var shipper = await userManager.FindByNameAsync(User.Identity.Name);
            var shippings = _db.Shippings.ToList();
            var model = new List<Shipping>();

            for (int i = 0; i < shippings.Count(); i++)
            {
                if (shippings[i].ShipperId == shipper.Id && shippings[i].Accepted && !shippings[i].Done)
                {
                    model.Add(shippings[i]);
                }
            }

            return View(model);
        }
    }
}
