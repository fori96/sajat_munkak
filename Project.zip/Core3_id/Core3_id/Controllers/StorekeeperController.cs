﻿using Core3_id.Areas.Identity.Data;
using Core3_id.Data;
using Core3_id.Models;
using Core3_id.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IEmailSender = Core3_id.Services.IEmailSender;

namespace Core3_id.Controllers
{
    [Authorize(Policy = "Storekeeper")]
    public class StorekeeperController : Controller
    {
        public readonly ApplicationDbContext _db;
        public readonly UserManager<Core3_idUser> UserManager;
        private readonly RoleManager<ApplicationRole> roleManager;
        private readonly IEmailSender _emailSender;

        public StorekeeperController(ApplicationDbContext db, RoleManager<ApplicationRole> roleManager, UserManager<Core3_idUser> userManager,
             IEmailSender emailSender)
        {
            this.roleManager = roleManager;
            _db = db;
            this.UserManager = userManager;
            _emailSender = emailSender;
        }

        [HttpGet]
        public async Task<IActionResult> ListPackages()
        {
            var user = await UserManager.FindByNameAsync(User.Identity.Name);
            var sk = _db.Storekeepers.SingleOrDefault(s => s.Id == user.Id);

            var storing = _db.Storings.ToList();
            var model = new List<Storing>();

            for (int i = 0; i < storing.Count(); i++)
            {
                if (storing[i].WhId == sk.WhId && !(storing[i].LeaveDate == null))
                {
                    model.Add(storing[i]);
                }
            }

            return View(model);
        }

        public async Task<IActionResult> PackageChecked(string packageid)
        {
            var package = await _db.Package.FindAsync(packageid);

            var user = await UserManager.FindByNameAsync(User.Identity.Name);
            var sk = _db.Storekeepers.SingleOrDefault(s => s.Id == user.Id);

            if(package.Status == "raktárba szállítva")
                package.Status = "raktárban ellenőrizve";

            if (package.Status == "raktárba szállítva(2)")
                package.Status = "raktárban ellenőrizve(2)";

            if (package.Status == "raktárba szállítva (vissza)")
                package.Status = "raktárba ellenőrizve (vissza)";

            if (package.Status == "raktárba szállítva (vissza,2)")
                package.Status = "raktárba ellenőrizve (vissza,2)";

            _db.Update(package);
            await _db.SaveChangesAsync();

            Checks check = new Checks();
            check.PackageId = package.PackageID;
            check.SkId = sk.Id;
            check.Date = DateTime.Now;

            _db.Add(check);
            var result = await _db.SaveChangesAsync();

            return RedirectToAction("ListPackages");
        }

        public async Task<IActionResult> ReportPackage(string packageid)
        {
            var package = await _db.Package.FindAsync(packageid);

            package.Status = "hibás";

            _db.Update(package);
            await _db.SaveChangesAsync();

            var sender = await UserManager.FindByIdAsync(package.Sender);
            await _emailSender.SendEmail(sender.Email, "HIbás csomag",
                        $"A csomag hibásnak lett nyilvánitva a rakrátban. \t" +
                        $"Kérjük látogassa meg oldalunk és döntsön a csomag további sorsáról." +
                        $"Csomag azonósítója: {package.PackageID}" +
                        $"" +
                        $"Szíves elnézését kérjük és köszönjük együtt működését." +
                        $"" +
                        $"Üdvözlettel a Sahara Caravan csapata");
            var rec = await UserManager.FindByIdAsync(package.Recipient);
            await _emailSender.SendEmail(rec.Email, "Hibás csomag",
                        $"Az onnek kültőd csomag hibásnak lett nyilvánitva a rakrátban. \t" +
                        $"Csomag további sorsáról egyeztessen a feladóval." +
                        $"Küldő: {rec.Name}" +
                        $"Csomag azonósítója: {package.PackageID}" +
                        $"" +
                        $"Szíves elnézését kérjük és köszönjük együtt működését." +
                        $"" +
                        $"Üdvözlettel a Sahara Caravan csapata");

            return RedirectToAction("CreateTicket");
        }

        public async Task<IActionResult> ReportProblem(string packageid)
        {
            var package = await _db.Package.FindAsync(packageid);

            package.Status = "elkeveredett";

            _db.Update(package);
            await _db.SaveChangesAsync();

            return RedirectToAction("ListPackages");
        }

        [HttpGet]
        public IActionResult CreateTicket()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateTicket(FailureTickets model)
        {
            if(model == null)
            {
                return View("Error");
            }

            FailureTickets ticket = model;

            _db.FailureTickets.Add(ticket);
            await _db.SaveChangesAsync();

            return RedirectToAction("ListPackages");
        }
    }
}
