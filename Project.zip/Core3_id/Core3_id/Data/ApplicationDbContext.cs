﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Core3_id.Areas.Identity.Data;
using Core3_id.Models;
using Microsoft.AspNetCore.Identity;
using Core3_id.Data;

namespace Core3_id.Models
{
    public partial class ApplicationDbContext : IdentityDbContext<Core3_idUser, ApplicationRole, string,
        ApplicationUserClaim, ApplicationUserRole, ApplicationUserLogin,
        ApplicationRoleClaim, ApplicationUserToken>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public string ConnectionString { get; set; }

        public ApplicationDbContext(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        public DbSet<Core3_idUser> Core3_IdUsers { get; set; }
        
        public DbSet<Package> Package { get; set; }

        public DbSet<Shipping> Shippings { get; set; }
        public DbSet<Storing> Storings { get; set; }
        public DbSet<Warehouse> Warehouses { get; set; }
        public DbSet<Shipper> Shippers { get; set; }
        public DbSet<Storekeeper> Storekeepers { get; set; }
        public DbSet<Checks> Checks { get; set; }
        public DbSet<Territories> Territories { get; set; }
        public DbSet<Feedbacks> Feedbacks { get; set; }
        public DbSet<OuterAddresses> OuterAddresses { get; set; }
        public DbSet<PickupPoint> PickupPoints { get; set; }
        public DbSet<FailureTickets> FailureTickets { get; set; }
        public DbSet<Confirmations> Confirmations { get; set; }


        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);

            builder.Entity<Core3_idUser>(b =>
            {
                // Each User can have many UserClaims
                b.HasMany(e => e.Claims)
                    .WithOne()
                    .HasForeignKey(uc => uc.UserId)
                    .IsRequired();
                // Each User can have many UserLogins
                b.HasMany(e => e.Logins)
                    .WithOne()
                    .HasForeignKey(ul => ul.UserId)
                    .IsRequired();

                // Each User can have many UserTokens
                b.HasMany(e => e.Tokens)
                    .WithOne()
                    .HasForeignKey(ut => ut.UserId)
                    .IsRequired();

                // Each User can have many entries in the UserRole join table
                b.HasMany(e => e.UserRoles)
                    .WithOne()
                    .HasForeignKey(ur => ur.UserId)
                    .IsRequired();
            });

            builder.Entity<ApplicationRole>(b =>
            {
                // Each Role can have many entries in the UserRole join table
                b.HasMany(e => e.UserRoles)
                    .WithOne(e => e.Role)
                    .HasForeignKey(ur => ur.RoleId)
                    .IsRequired();

                // Each Role can have many associated RoleClaims
                b.HasMany(e => e.RoleClaims)
                    .WithOne(e => e.Role)
                    .HasForeignKey(rc => rc.RoleId)
                    .IsRequired();
            });
        }

        
    }
}
