﻿using Core3_id.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Data
{
    public class ApplicationUserRole : IdentityUserRole<string>
    {
        public virtual Core3_idUser User { get; set; }
        public virtual ApplicationRole Role { get; set; }




    }

    public class ApplicationUserClaim : IdentityUserClaim<string>
    {
        public virtual Core3_idUser User { get; set; }
    }

    public class ApplicationUserLogin : IdentityUserLogin<string>
    {
        public virtual Core3_idUser User { get; set; }
    }

    public class ApplicationRoleClaim : IdentityRoleClaim<string>
    {
        public virtual ApplicationRole Role { get; set; }
    }

    public class ApplicationUserToken : IdentityUserToken<string>
    {
        public virtual Core3_idUser User { get; set; }
    }

}
