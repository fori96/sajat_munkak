﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Core3_id.Migrations
{
    public partial class AddAR : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Prize",
                table: "Package",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Prize",
                table: "Package");
        }
    }
}
