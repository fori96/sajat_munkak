﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Core3_id.Migrations
{
    public partial class PickupPointAndOutAddress : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Objest",
                table: "Feedbacks");

            migrationBuilder.AddColumn<string>(
                name: "Object",
                table: "Feedbacks",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "OuterAddresses",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    PackageID = table.Column<string>(nullable: true),
                    Country = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    Postalcode = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OuterAddresses", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PickupPoints",
                columns: table => new
                {
                    Id = table.Column<string>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Country = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    Postalcode = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PickupPoints", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OuterAddresses");

            migrationBuilder.DropTable(
                name: "PickupPoints");

            migrationBuilder.DropColumn(
                name: "Object",
                table: "Feedbacks");

            migrationBuilder.AddColumn<string>(
                name: "Objest",
                table: "Feedbacks",
                type: "longtext CHARACTER SET utf8mb4",
                nullable: true);
        }
    }
}
