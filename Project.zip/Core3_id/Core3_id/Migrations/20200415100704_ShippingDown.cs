﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Core3_id.Migrations
{
    public partial class ShippingDown : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Shippings");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Shippings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Accepted = table.Column<bool>(type: "tinyint(1)", nullable: false),
                    Done = table.Column<bool>(type: "tinyint(1)", nullable: false),
                    PackageId = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true),
                    ShipperId = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true),
                    ShippingDate = table.Column<DateTime>(type: "datetime(6)", nullable: false),
                    WhereFrom = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true),
                    WhereTo = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Shippings", x => x.Id);
                });
        }
    }
}
