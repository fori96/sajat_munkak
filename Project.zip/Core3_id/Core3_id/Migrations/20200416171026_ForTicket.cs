﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Core3_id.Migrations
{
    public partial class ForTicket : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "User",
                table: "FailureTickets");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "FailureTickets",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "varchar(255) CHARACTER SET utf8mb4")
                .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn);

            migrationBuilder.AddColumn<DateTime>(
                name: "Date",
                table: "FailureTickets",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "PackageId",
                table: "FailureTickets",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Storekeeper",
                table: "FailureTickets",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Date",
                table: "FailureTickets");

            migrationBuilder.DropColumn(
                name: "PackageId",
                table: "FailureTickets");

            migrationBuilder.DropColumn(
                name: "Storekeeper",
                table: "FailureTickets");

            migrationBuilder.AlterColumn<string>(
                name: "Id",
                table: "FailureTickets",
                type: "varchar(255) CHARACTER SET utf8mb4",
                nullable: false,
                oldClrType: typeof(int))
                .OldAnnotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn);

            migrationBuilder.AddColumn<string>(
                name: "User",
                table: "FailureTickets",
                type: "longtext CHARACTER SET utf8mb4",
                nullable: true);
        }
    }
}
