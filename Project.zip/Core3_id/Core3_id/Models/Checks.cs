﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Models
{
    public class Checks
    {
        [Key]
        public string PackageId { get; set; }
        public string SkId { get; set; }
        public DateTime Date { get; set; }
    }
}
