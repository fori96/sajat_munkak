﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Models
{
    public class Confirmations
    { 
        [Key]
        public int Id { get; set;}
        public string UserId { get; set; }
        public string Email { get; set; }
        public string ConfirmationCode { get; set; }
        public bool Confirmed { get; set; }
    }
}
