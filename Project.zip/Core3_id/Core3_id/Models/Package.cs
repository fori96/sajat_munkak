﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Models
{
    public class Package
    {
        [Key]
        public string PackageID { get; set; }
        public string Sender { get; set; }
        public string Recipient { get; set; }
        public string PayMethod { get; set; } = "utánvét";
        public string Status { get; set; }
        public string Type { get; set; }
        public int Size { get; set; }

        public int Prize { get; set; }

        public DateTime? ShipDate { get; set; }
        public DateTime? DeliveryDate { get; set; }
        //public string? Comment { get; set; }


        //public enum StatusTypes { felvétel_alatt, 
        //    raktárba_szállítva, 
        //    raktárban_ellenőrizve,
        //    átszállítás_alatt,
        //    kiszállítás_alatt,
        //    kész,
        //    hibás,
        //    törölve
        //};
    }
}
