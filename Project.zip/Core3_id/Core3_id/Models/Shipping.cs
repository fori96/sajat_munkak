﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Models
{
    public class Shipping
    {
        [Key]
        public int Id { get; set; }
        public string PackageId { get; set; }
        public string ShipperId { get; set; }
        public string WhereFrom { get; set; }
        public string WhereTo { get; set; }
        public DateTime ShippingDate { get; set; }
        public bool Accepted { get; set; }
        public bool Done { get; set; }
    }
}
