﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Models
{
    public class Storekeeper
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string WhId { get; set; }
    }
}
