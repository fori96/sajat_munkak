﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.ViewModels
{
    public class AddShipperToPackageVM
    {
        public string SId { get; set; }
        public string PId { get; set; }
        public string Where_From { get; set; }
        public string Where_To { get; set; }
        public string Name { get; set; }
        public bool IsSelected { get; set; }
    }
}
