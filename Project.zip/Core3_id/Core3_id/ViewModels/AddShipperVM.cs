﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Models
{
    public class AddShipperVM
    {
        public string Name { get; set; }
        public string ShipperId { get; set; }
        public bool IsSelected { get; set; }

    }
}
