﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.ViewModels
{
    public class EditTerritoryViewModel
    {
        public EditTerritoryViewModel()
        {
            Shippers = new List<string>();
        }

        public string Id { get; set; }

        [Required(ErrorMessage = "required")]
        public string Name { get; set; }

        public string Central { get; set; }

        public List<string> Shippers { get; set; }
    }
}
