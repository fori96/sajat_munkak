﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Models
{
    public class EditUserModel
    {
        public string Id { get; set; }

        public string Username { get; set; }

        [DataType(DataType.Text)]
        [Display(Name = "Full name")]
        public string Name { get; set; }

        [Display(Name = "Birth Date")]
        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }

        [Display(Name = "Lakcm")]
        public string Address { get; set; }

        [Display(Name = "Város")]
        public string City { get; set; }

        [Display(Name = "Irányítószám")]
        public string Postalcode { get; set; }

        [Phone]
        [Display(Name = "Phone number")]
        public string PhoneNumber { get; set; }
    }
}
