﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Models
{
    public class ListPackageViewModel
    {
        

        public string Source_Address { get; set; }
        public string Destination_Address { get; set; }
        public List<Package> List { get; set; }

    }
}
