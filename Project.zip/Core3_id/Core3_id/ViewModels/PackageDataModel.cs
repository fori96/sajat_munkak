﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core3_id.Models
{
    public class PackageDataModel
    {
        public string Id { get; set; }
        public string Recipient { get; set; }
        public string PickupPoint { get; set; }
        public OuterAddresses OuterAddresses { get; set; }
        public string Type { get; set; }
        public int Size { get; set; }
        public string PayMethod { get; set; } = "utánvét";

    }
}
